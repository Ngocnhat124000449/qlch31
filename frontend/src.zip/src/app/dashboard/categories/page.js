"use client";

import { useEffect, useState } from "react";
import PageHeader from "@/components/admin/PageHeader";
import { Boxes, Pencil, Trash2 } from "lucide-react";
import { adminListCategories } from "@/lib/adminApi";

function toStatusLabel(v) {
  const on = v === true || String(v).toLowerCase() === "true";
  return on ? "Hoạt động" : "Không hoạt động";
}

export default function CategoriesPage() {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const { categories } = await adminListCategories({ all: true });
        if (!mounted) return;
        setRows(Array.isArray(categories) ? categories : []);
      } catch (e) {
        if (!mounted) return;
        setError(e?.message || "Không thể tải danh mục");
        setRows([]);
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  return (
    <div className="space-y-5">
      <PageHeader
        title="Quản lý danh mục"
        subtitle="Danh sách danh mục lấy trực tiếp từ API."
        actionLabel="＋ Thêm danh mục"
        onAction={() => {}}
      />

      <div className="rounded-2xl border border-white/10 bg-white/5 backdrop-blur-xl">
        <div className="grid grid-cols-7 gap-3 px-5 py-3 text-xs text-white/55">
          <div>Icon</div>
          <div>Tên danh mục</div>
          <div className="col-span-2">Slug</div>
          <div className="text-center">Trạng thái</div>
          <div>Ngày tạo</div>
          <div className="text-right">Hành động</div>
        </div>

        <div className="divide-y divide-white/10">
          {loading ? (
            <div className="px-5 py-6 text-sm text-white/60">Đang tải…</div>
          ) : rows.length === 0 ? (
            <div className="px-5 py-6 text-sm text-white/60">
              {error || "Chưa có danh mục."}
            </div>
          ) : (
            rows.map((r) => (
              <div
                key={String(r?.danhmucid ?? r?.id ?? r?.tenviettat ?? r?.ten ?? Math.random())}
                className="grid grid-cols-7 items-center gap-3 px-5 py-4"
              >
                <div className="grid h-10 w-10 place-items-center rounded-xl bg-white/5 ring-1 ring-white/10">
                  <Boxes className="h-5 w-5 text-white/80" />
                </div>
                <div className="text-sm font-medium">{r?.ten ?? r?.name ?? "-"}</div>
                <div className="col-span-2 text-sm text-white/65">
                  {r?.tenviettat ?? r?.slug ?? "-"}
                </div>
                <div className="flex justify-center">
                  <span className="rounded-full bg-indigo-500/25 px-4 py-1 text-xs ring-1 ring-indigo-400/30">
                    {toStatusLabel(r?.trangthai)}
                  </span>
                </div>
                <div className="text-sm text-white/70">
                  {r?.created_at ? new Date(r.created_at).toLocaleString("vi-VN") : "-"}
                </div>
                <div className="flex justify-end gap-3">
                  <button className="grid h-9 w-9 place-items-center rounded-xl bg-white/5 ring-1 ring-white/10 hover:bg-white/10">
                    <Pencil className="h-4 w-4" />
                  </button>
                  <button className="grid h-9 w-9 place-items-center rounded-xl bg-white/5 ring-1 ring-white/10 hover:bg-white/10">
                    <Trash2 className="h-4 w-4 text-rose-300" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
