"use client";

import { Bell, Moon } from "lucide-react";

export default function AdminTopbar({ me }) {
  const name =
    me?.tenhienthi ||
    me?.tenHienThi ||
    me?.fullname ||
    me?.fullName ||
    me?.hoten ||
    me?.hoTen ||
    me?.name ||
    "Admin";

  return (
    <div className="sticky top-0 z-20 border-b border-border bg-background/60 backdrop-blur-xl">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-end gap-2 px-6">
        <button
          type="button"
          className="grid h-9 w-9 place-items-center rounded-xl bg-card ring-1 ring-border hover:bg-muted/50"
          aria-label="Theme"
        >
          <Moon className="h-4 w-4 text-foreground" />
        </button>
        <button
          type="button"
          className="grid h-9 w-9 place-items-center rounded-xl bg-card ring-1 ring-border hover:bg-muted/50"
          aria-label="Notifications"
        >
          <Bell className="h-4 w-4 text-foreground" />
        </button>

        <div className="ml-1 flex items-center gap-3">
          <div className="hidden text-right sm:block">
            <div className="text-sm font-medium leading-4">{name}</div>
            <div className="text-xs text-muted-foreground leading-4">Quản trị viên</div>
          </div>
          <div className="h-9 w-9 overflow-hidden rounded-full ring-1 ring-border bg-card" />
        </div>
      </div>
    </div>
  );
}
